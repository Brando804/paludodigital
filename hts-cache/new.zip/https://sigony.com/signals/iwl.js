<!doctype html>
<html lang="en-US" prefix="og: https://ogp.me/ns#" class="no-js">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5" />	<style>img:is([sizes="auto" i], [sizes^="auto," i]) { contain-intrinsic-size: 3000px 1500px }</style>
	
<!-- Search Engine Optimization by Rank Math - https://rankmath.com/ -->
<title>Page Not Found - SIGO NY</title>
<meta name="robots" content="follow, noindex"/>
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="article" />
<meta property="og:title" content="Page Not Found - SIGO NY" />
<meta property="og:site_name" content="SIGO NY" />
<meta property="og:image" content="https://sigony.com/wp-content/uploads/2024/01/cropped-SIGO_NY_favicon_01.png" />
<meta property="og:image:secure_url" content="https://sigony.com/wp-content/uploads/2024/01/cropped-SIGO_NY_favicon_01.png" />
<meta property="og:image:width" content="512" />
<meta property="og:image:height" content="512" />
<meta property="og:image:type" content="image/png" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="Page Not Found - SIGO NY" />
<meta name="twitter:image" content="https://sigony.com/wp-content/uploads/2024/01/cropped-SIGO_NY_favicon_01.png" />
<script type="application/ld+json" class="rank-math-schema">{"@context":"https://schema.org","@graph":[{"@type":"Organization","@id":"https://sigony.com/#organization","name":"SIGO NY","url":"https://sigony.com","logo":{"@type":"ImageObject","@id":"https://sigony.com/#logo","url":"https://sigony.com/wp-content/uploads/2024/01/SIGO_NY_favicon_01.png","contentUrl":"https://sigony.com/wp-content/uploads/2024/01/SIGO_NY_favicon_01.png","caption":"SIGO NY","inLanguage":"en-US","width":"512","height":"512"}},{"@type":"WebSite","@id":"https://sigony.com/#website","url":"https://sigony.com","name":"SIGO NY","publisher":{"@id":"https://sigony.com/#organization"},"inLanguage":"en-US"},{"@type":"WebPage","@id":"#webpage","url":"","name":"Page Not Found - SIGO NY","isPartOf":{"@id":"https://sigony.com/#website"},"inLanguage":"en-US"}]}</script>
<!-- /Rank Math WordPress SEO plugin -->

<link rel='dns-prefetch' href='//www.googletagmanager.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel="alternate" type="application/rss+xml" title="SIGO NY &raquo; Feed" href="https://sigony.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="SIGO NY &raquo; Comments Feed" href="https://sigony.com/comments/feed/" />
<link rel="preload" href="https://sigony.com/wp-content/themes/salient/css/fonts/icomoon.woff?v=1.6" as="font" type="font/woff" crossorigin="anonymous"><style id='gutenberg-content-editor-style-inline-css' type='text/css'>
.wp-block-create-block-content-commands{background-color:#21759b;color:#fff;padding:2px}.block-editor-block-toolbar .dashicons-admin-generic,.dashicons-screenoptions.seoaic-icon{background-color:#000;background-image:url(/wp-content/plugins/seoai-client/gutenberg/content-editor/build/content-editor/../images/s-logo.88bc4401.png)!important;background-position:center 5px;background-repeat:no-repeat;background-size:60%;height:28px;width:28px}.block-editor-block-toolbar .dashicons-admin-generic:before,.dashicons-screenoptions.seoaic-icon:before{content:""!important}

</style>
<style id='seoaic-faq-block-style-inline-css' type='text/css'>
.wp-block-create-block-content-commands{background-color:#21759b;color:#fff;padding:2px}

</style>
<style id='seoaic-generate-image-block-style-inline-css' type='text/css'>
.seoaic-generated-image-section img{max-width:100%}

</style>
<style id='rank-math-toc-block-style-inline-css' type='text/css'>
.wp-block-rank-math-toc-block nav ol{counter-reset:item}.wp-block-rank-math-toc-block nav ol li{display:block}.wp-block-rank-math-toc-block nav ol li:before{content:counters(item, ".") ". ";counter-increment:item}

</style>
<style id='rank-math-rich-snippet-style-inline-css' type='text/css'>
/*!
* Plugin:  Rank Math
* URL: https://rankmath.com/wordpress/plugin/seo-suite/
* Name:  rank-math-review-snippet.css
*/@-webkit-keyframes spin{0%{-webkit-transform:rotate(0deg)}100%{-webkit-transform:rotate(-360deg)}}@keyframes spin{0%{-webkit-transform:rotate(0deg)}100%{-webkit-transform:rotate(-360deg)}}@keyframes bounce{from{-webkit-transform:translateY(0px);transform:translateY(0px)}to{-webkit-transform:translateY(-5px);transform:translateY(-5px)}}@-webkit-keyframes bounce{from{-webkit-transform:translateY(0px);transform:translateY(0px)}to{-webkit-transform:translateY(-5px);transform:translateY(-5px)}}@-webkit-keyframes loading{0%{background-size:20% 50% ,20% 50% ,20% 50%}20%{background-size:20% 20% ,20% 50% ,20% 50%}40%{background-size:20% 100%,20% 20% ,20% 50%}60%{background-size:20% 50% ,20% 100%,20% 20%}80%{background-size:20% 50% ,20% 50% ,20% 100%}100%{background-size:20% 50% ,20% 50% ,20% 50%}}@keyframes loading{0%{background-size:20% 50% ,20% 50% ,20% 50%}20%{background-size:20% 20% ,20% 50% ,20% 50%}40%{background-size:20% 100%,20% 20% ,20% 50%}60%{background-size:20% 50% ,20% 100%,20% 20%}80%{background-size:20% 50% ,20% 50% ,20% 100%}100%{background-size:20% 50% ,20% 50% ,20% 50%}}:root{--rankmath-wp-adminbar-height: 0}#rank-math-rich-snippet-wrapper{overflow:hidden}#rank-math-rich-snippet-wrapper h5.rank-math-title{display:block;font-size:18px;line-height:1.4}#rank-math-rich-snippet-wrapper .rank-math-review-image{float:right;max-width:40%;margin-left:15px}#rank-math-rich-snippet-wrapper .rank-math-review-data{margin-bottom:15px}#rank-math-rich-snippet-wrapper .rank-math-total-wrapper{width:100%;padding:0 0 20px 0;float:left;clear:both;position:relative;-webkit-box-sizing:border-box;box-sizing:border-box}#rank-math-rich-snippet-wrapper .rank-math-total-wrapper .rank-math-total{border:0;display:block;margin:0;width:auto;float:left;text-align:left;padding:0;font-size:24px;line-height:1;font-weight:700;-webkit-box-sizing:border-box;box-sizing:border-box;overflow:hidden}#rank-math-rich-snippet-wrapper .rank-math-total-wrapper .rank-math-review-star{float:left;margin-left:15px;margin-top:5px;position:relative;z-index:99;line-height:1}#rank-math-rich-snippet-wrapper .rank-math-total-wrapper .rank-math-review-star .rank-math-review-result-wrapper{display:inline-block;white-space:nowrap;position:relative;color:#e7e7e7}#rank-math-rich-snippet-wrapper .rank-math-total-wrapper .rank-math-review-star .rank-math-review-result-wrapper .rank-math-review-result{position:absolute;top:0;left:0;overflow:hidden;white-space:nowrap;color:#ffbe01}#rank-math-rich-snippet-wrapper .rank-math-total-wrapper .rank-math-review-star .rank-math-review-result-wrapper i{font-size:18px;-webkit-text-stroke-width:1px;font-style:normal;padding:0 2px;line-height:inherit}#rank-math-rich-snippet-wrapper .rank-math-total-wrapper .rank-math-review-star .rank-math-review-result-wrapper i:before{content:"\2605"}body.rtl #rank-math-rich-snippet-wrapper .rank-math-review-image{float:left;margin-left:0;margin-right:15px}body.rtl #rank-math-rich-snippet-wrapper .rank-math-total-wrapper .rank-math-total{float:right}body.rtl #rank-math-rich-snippet-wrapper .rank-math-total-wrapper .rank-math-review-star{float:right;margin-left:0;margin-right:15px}body.rtl #rank-math-rich-snippet-wrapper .rank-math-total-wrapper .rank-math-review-star .rank-math-review-result{left:auto;right:0}@media screen and (max-width: 480px){#rank-math-rich-snippet-wrapper .rank-math-review-image{display:block;max-width:100%;width:100%;text-align:center;margin-right:0}#rank-math-rich-snippet-wrapper .rank-math-review-data{clear:both}}.clear{clear:both}

</style>
<style id='global-styles-inline-css' type='text/css'>
:root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:root { --wp--style--global--content-size: 1300px;--wp--style--global--wide-size: 1300px; }:where(body) { margin: 0; }.wp-site-blocks > .alignleft { float: left; margin-right: 2em; }.wp-site-blocks > .alignright { float: right; margin-left: 2em; }.wp-site-blocks > .aligncenter { justify-content: center; margin-left: auto; margin-right: auto; }:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}.is-layout-flow > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}.is-layout-flow > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}.is-layout-flow > .aligncenter{margin-left: auto !important;margin-right: auto !important;}.is-layout-constrained > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}.is-layout-constrained > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}.is-layout-constrained > .aligncenter{margin-left: auto !important;margin-right: auto !important;}.is-layout-constrained > :where(:not(.alignleft):not(.alignright):not(.alignfull)){max-width: var(--wp--style--global--content-size);margin-left: auto !important;margin-right: auto !important;}.is-layout-constrained > .alignwide{max-width: var(--wp--style--global--wide-size);}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}body{padding-top: 0px;padding-right: 0px;padding-bottom: 0px;padding-left: 0px;}:root :where(.wp-element-button, .wp-block-button__link){background-color: #32373c;border-width: 0;color: #fff;font-family: inherit;font-size: inherit;line-height: inherit;padding: calc(0.667em + 2px) calc(1.333em + 2px);text-decoration: none;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
:root :where(.wp-block-pullquote){font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='salient-grid-system-css' href='https://sigony.com/wp-content/themes/salient/css/build/grid-system.css?ver=17.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='main-styles-css' href='https://sigony.com/wp-content/themes/salient/css/build/style.css?ver=17.0.2' type='text/css' media='all' />
<style id='main-styles-inline-css' type='text/css'>

		#error-404{
		  text-align:center;
		  padding: 10% 0;
		  position: relative;
		  z-index: 10;
		}
		body.error {
		  padding: 0;
		}
		body #error-404[data-cc="true"] h1,
		body #error-404[data-cc="true"] h2,
		body #error-404[data-cc="true"] p {
		  color: inherit;
		}
		body.error404 .error-404-bg-img,
		body.error404 .error-404-bg-img-overlay {
		  position: absolute;
		  top: 0;
		  left: 0;
		  width: 100%;
		  height: 100%;
		  background-size: cover;
		  background-position: 50%;
		  z-index: 1;
		}
		body.error404 .error-404-bg-img-overlay {
		  opacity: 0.8;
		}
		body #error-404 h1,
		body #error-404 h2 {
		  font-family: "Open Sans";
		  font-weight:700
		}
		body #ajax-content-wrap #error-404 h1 {
		  font-size:250px;
		  line-height:250px;
		}
		body #ajax-content-wrap #error-404 h2 {
		  font-size:54px;
		}
		body #error-404 .nectar-button {
		  margin-top: 50px;
		}

		body.error404 .main-content > .row > .col.span_12 {
			padding-bottom: 0;
		}

		@media only screen and (max-width : 690px) {

			body .row #error-404 h1,
			body #ajax-content-wrap #error-404 h1 {
				font-size: 150px;
				line-height: 150px;
			}

			body #ajax-content-wrap #error-404 h2 {
				font-size: 32px;
			}

			body .row #error-404 {
				margin-bottom: 0;
			}
		}
		
html body[data-header-resize="1"] .container-wrap, 
			html body[data-header-format="left-header"][data-header-resize="0"] .container-wrap, 
			html body[data-header-resize="0"] .container-wrap, 
			body[data-header-format="left-header"][data-header-resize="0"] .container-wrap { 
				padding-top: 0; 
			} 
			.main-content > .row > #breadcrumbs.yoast { 
				padding: 20px 0; 
			}
</style>
<link rel='stylesheet' id='nectar-header-layout-centered-menu-css' href='https://sigony.com/wp-content/themes/salient/css/build/header/header-layout-centered-menu.css?ver=17.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='nectar-header-perma-transparent-css' href='https://sigony.com/wp-content/themes/salient/css/build/header/header-perma-transparent.css?ver=17.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='nectar_default_font_open_sans-css' href='https://fonts.googleapis.com/css?family=Open+Sans%3A300%2C400%2C600%2C700&#038;subset=latin%2Clatin-ext&#038;display=swap' type='text/css' media='all' />
<link rel='stylesheet' id='responsive-css' href='https://sigony.com/wp-content/themes/salient/css/build/responsive.css?ver=17.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='skin-material-css' href='https://sigony.com/wp-content/themes/salient/css/build/skin-material.css?ver=17.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='salient-wp-menu-dynamic-css' href='https://sigony.com/wp-content/uploads/salient/menu-dynamic.css?ver=825' type='text/css' media='all' />
<link rel='stylesheet' id='js_composer_front-css' href='https://sigony.com/wp-content/plugins/js_composer_salient/assets/css/js_composer.min.css?ver=7.8.1' type='text/css' media='all' />
<link rel='stylesheet' id='dynamic-css-css' href='https://sigony.com/wp-content/themes/salient/css/salient-dynamic-styles.css?ver=57846' type='text/css' media='all' />
<style id='dynamic-css-inline-css' type='text/css'>
#header-space{background-color:#ffffff}@media only screen and (min-width:1000px){body #ajax-content-wrap.no-scroll{min-height:calc(100vh - 110px);height:calc(100vh - 110px)!important;}}@media only screen and (min-width:1000px){#page-header-wrap.fullscreen-header,#page-header-wrap.fullscreen-header #page-header-bg,html:not(.nectar-box-roll-loaded) .nectar-box-roll > #page-header-bg.fullscreen-header,.nectar_fullscreen_zoom_recent_projects,#nectar_fullscreen_rows:not(.afterLoaded) > div{height:calc(100vh - 109px);}.wpb_row.vc_row-o-full-height.top-level,.wpb_row.vc_row-o-full-height.top-level > .col.span_12{min-height:calc(100vh - 109px);}html:not(.nectar-box-roll-loaded) .nectar-box-roll > #page-header-bg.fullscreen-header{top:110px;}.nectar-slider-wrap[data-fullscreen="true"]:not(.loaded),.nectar-slider-wrap[data-fullscreen="true"]:not(.loaded) .swiper-container{height:calc(100vh - 108px)!important;}.admin-bar .nectar-slider-wrap[data-fullscreen="true"]:not(.loaded),.admin-bar .nectar-slider-wrap[data-fullscreen="true"]:not(.loaded) .swiper-container{height:calc(100vh - 108px - 32px)!important;}}.admin-bar[class*="page-template-template-no-header"] .wpb_row.vc_row-o-full-height.top-level,.admin-bar[class*="page-template-template-no-header"] .wpb_row.vc_row-o-full-height.top-level > .col.span_12{min-height:calc(100vh - 32px);}body[class*="page-template-template-no-header"] .wpb_row.vc_row-o-full-height.top-level,body[class*="page-template-template-no-header"] .wpb_row.vc_row-o-full-height.top-level > .col.span_12{min-height:100vh;}@media only screen and (max-width:999px){.using-mobile-browser #nectar_fullscreen_rows:not(.afterLoaded):not([data-mobile-disable="on"]) > div{height:calc(100vh - 108px);}.using-mobile-browser .wpb_row.vc_row-o-full-height.top-level,.using-mobile-browser .wpb_row.vc_row-o-full-height.top-level > .col.span_12,[data-permanent-transparent="1"].using-mobile-browser .wpb_row.vc_row-o-full-height.top-level,[data-permanent-transparent="1"].using-mobile-browser .wpb_row.vc_row-o-full-height.top-level > .col.span_12{min-height:calc(100vh - 108px);}html:not(.nectar-box-roll-loaded) .nectar-box-roll > #page-header-bg.fullscreen-header,.nectar_fullscreen_zoom_recent_projects,.nectar-slider-wrap[data-fullscreen="true"]:not(.loaded),.nectar-slider-wrap[data-fullscreen="true"]:not(.loaded) .swiper-container,#nectar_fullscreen_rows:not(.afterLoaded):not([data-mobile-disable="on"]) > div{height:calc(100vh - 55px);}.wpb_row.vc_row-o-full-height.top-level,.wpb_row.vc_row-o-full-height.top-level > .col.span_12{min-height:calc(100vh - 55px);}body[data-transparent-header="false"] #ajax-content-wrap.no-scroll{min-height:calc(100vh - 55px);height:calc(100vh - 55px);}}.wpb_column.el_spacing_0px > .vc_column-inner > .wpb_wrapper > div:not(:last-child),.wpb_column.el_spacing_0px > .n-sticky > .vc_column-inner > .wpb_wrapper > div:not(:last-child){margin-bottom:0;}.nectar-post-grid[data-grid-item-height="30vh"] .nectar-post-grid-item{min-height:30vh;}.nectar-post-grid[data-border-radius="25px"][data-text-layout="all_bottom_left_shadow"] .nectar-post-grid-item:before,.nectar-post-grid-wrap:not([data-style="content_under_image"]) .nectar-post-grid[data-border-radius="25px"] .nectar-post-grid-item .inner,.nectar-post-grid[data-border-radius="25px"] .bg-overlay,.nectar-post-grid[data-border-radius="25px"][data-shadow-hover="yes"] .nectar-post-grid-item:after,.nectar-post-grid[data-border-radius="25px"] .nectar-post-grid-item-bg,.nectar-post-grid[data-border-radius="25px"] .nectar-post-grid-item-bg-wrap,[data-style="mouse_follow_image"] .nectar-post-grid[data-border-radius="25px"] .nectar-post-grid-item-bg-wrap-inner,.nectar-post-grid[data-border-radius="25px"][data-text-layout="all_bottom_left_shadow"] .nectar-post-grid-item div.inner:before{border-radius:25px;}.nectar-post-grid[data-border-radius="25px"] .nectar-post-grid-item-bg,.nectar-post-grid[data-border-radius="25px"] .nectar-post-grid-item-bg-wrap{overflow:hidden;}.nectar-post-grid[data-border-radius="25px"] .nectar-post-grid-item-bg-wrap{transform:translateZ(0);}.nectar-post-grid .meta-category .style-button{padding:.5em 1em;line-height:1!important;background-color:var(--nectar-accent-color);}#ajax-content-wrap .nectar-post-grid .meta-category .style-button,body .nectar-post-grid .meta-category .style-button{color:#fff;}.nectar-post-grid .meta-category .style-button:before{display:none;}@media only screen and (max-width:690px){.vc_col-xs-4 .nectar-post-grid .nectar-post-grid-item .meta-excerpt,.vc_col-xs-6 .nectar-post-grid .nectar-post-grid-item .meta-excerpt{font-size:12px;}.nectar-post-grid .nectar-post-grid-item .content .post-heading,.nectar-post-grid-wrap:not([data-style=content_overlaid]) .nectar-post-grid-item .content .meta-excerpt{max-width:100%;}}#ajax-content-wrap .nectar-post-grid[data-columns="1"] > .nectar-post-grid-item:nth-child(1){margin-top:0;}#ajax-content-wrap .nectar-post-grid[data-columns="1"] > .nectar-post-grid-item:last-child{margin-bottom:0;}.wpb_row.full-width-content .vc_col-sm-12 .nectar-post-grid[data-grid-spacing="10px"]{margin:10px;}.nectar-post-grid[data-grid-spacing="10px"]{margin-left:-10px;margin-right:-10px;}@media only screen and (min-width:1000px){body[data-body-border="1"] .wpb_row.full-width-content .vc_col-sm-12 .nectar-post-grid[data-grid-spacing="10px"]{margin:10px -9px;}}.nectar-post-grid[data-grid-spacing="10px"] .nectar-post-grid-item{margin:10px;}.nectar-post-grid[data-columns="4"][data-grid-spacing="10px"] .nectar-post-grid-item{width:calc(25% - 20px);}.nectar-post-grid[data-columns="3"][data-grid-spacing="10px"] .nectar-post-grid-item{width:calc(33.32% - 20px);}.nectar-post-grid[data-columns="2"][data-grid-spacing="10px"] .nectar-post-grid-item{width:calc(50% - 20px);}@media only screen and (max-width:999px) and (min-width:691px){body .nectar-post-grid[data-columns][data-grid-spacing="10px"]:not([data-columns="1"]):not([data-masonry="yes"]) .nectar-post-grid-item{width:calc(50% - 20px);}}@media only screen and (min-width:1000px){.nectar-post-grid.custom_font_size_3vw .post-heading{font-size:3vw;}}@media only screen and (min-width:1000px){body #ajax-content-wrap .custom_font_size_3vw.font_size_max_54px.nectar-post-grid .nectar-post-grid-item .post-heading,body .custom_font_size_3vw.font_size_max_54px.nectar-post-grid .nectar-post-grid-item .post-heading{font-size:min(54px,3vw);}}@media only screen and (min-width:1000px){body #ajax-content-wrap .custom_font_size_3vw.font_size_max_54px.nectar-post-grid .nectar-post-grid-item .post-heading,body .custom_font_size_3vw.font_size_max_54px.nectar-post-grid .nectar-post-grid-item .post-heading,body #header-outer .custom_font_size_3vw.font_size_max_54px.nectar-post-grid .nectar-post-grid-item .post-heading{font-size:min(54px,3vw);}}@media only screen and (max-width:999px){body #ajax-content-wrap .font_size_tablet_5vw.font_size_max_54px.nectar-post-grid .nectar-post-grid-item .post-heading,body .font_size_tablet_5vw.font_size_max_54px.nectar-post-grid .nectar-post-grid-item .post-heading{font-size:min(54px,5vw);}}@media only screen and (max-width:999px){body #ajax-content-wrap .container-wrap .font_size_tablet_5vw.font_size_max_54px.nectar-post-grid .nectar-post-grid-item .post-heading,body .container-wrap .font_size_tablet_5vw.font_size_max_54px.nectar-post-grid .nectar-post-grid-item .post-heading,body #header-outer .font_size_tablet_5vw.font_size_max_54px.nectar-post-grid .nectar-post-grid-item .post-heading{font-size:min(54px,5vw);}}@media only screen and (max-width:690px){html body #ajax-content-wrap .font_size_phone_34px.font_size_max_54px.nectar-post-grid .nectar-post-grid-item .post-heading,html body .font_size_phone_34px.font_size_max_54px.nectar-post-grid .nectar-post-grid-item .post-heading{font-size:min(54px,34px);}}@media only screen and (max-width:690px){html body #ajax-content-wrap .container-wrap .font_size_phone_34px.font_size_max_54px.nectar-post-grid .nectar-post-grid-item .post-heading,html body .container-wrap .font_size_phone_34px.font_size_max_54px.nectar-post-grid .nectar-post-grid-item .post-heading,html body #header-outer .font_size_phone_34px.font_size_max_54px.nectar-post-grid .nectar-post-grid-item .post-heading{font-size:min(54px,34px);}}.nectar-post-grid-item .bg-overlay[data-opacity="0.1"]{opacity:0.1;}.nectar-post-grid-item:hover .bg-overlay[data-hover-opacity="0.2"]{opacity:0.2;}.nectar-post-grid.text-opacity-hover-1 .nectar-post-grid-item:hover .content{opacity:1;}.category-position-before-title.nectar-post-grid .nectar-post-grid-item .item-meta-extra{margin-top:0;}.category-position-before-title .item-main > .nectar-post-grid-item__meta-wrap:not(:empty){margin-top:10px;}.overlaid-aspect-ratio-image-size-16-9 .nectar-post-grid-item{min-height:0!important;}.overlaid-aspect-ratio-image-size-16-9 .nectar-post-grid-item > .inner{aspect-ratio:16 / 9;position:relative;}@media only screen and (max-width:690px){body .nectar-post-grid[data-columns][data-grid-spacing] .nectar-post-grid-item{padding-bottom:0;}}.category-button-color-rgba__10_10_10_0--2__ .meta-category a.style-button{background-color:rgba(10,10,10,0.2);backdrop-filter:blur(10px);}.nectar-scrolling-text.text_space_medium[data-spacing="true"] .nectar-scrolling-text-inner > *{padding-left:1.1em;}@media only screen and (min-width:1000px){.nectar-scrolling-text.font_size_7vw .nectar-scrolling-text-inner *{font-size:7vw;line-height:1em;}}@media only screen and (max-width:999px){.nectar-scrolling-text.font_size_mobile_10vw .nectar-scrolling-text-inner *{font-size:10vw;line-height:1.1em;}}.screen-reader-text,.nectar-skip-to-content:not(:focus){border:0;clip:rect(1px,1px,1px,1px);clip-path:inset(50%);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute!important;width:1px;word-wrap:normal!important;}.row .col img:not([srcset]){width:auto;}.row .col img.img-with-animation.nectar-lazy:not([srcset]){width:100%;}
</style>
<link rel='stylesheet' id='salient-child-style-css' href='https://sigony.com/wp-content/themes/salient-child/style.css?ver=17.0.2' type='text/css' media='all' />
<script type="text/javascript" id="breeze-prefetch-js-extra">
/* <![CDATA[ */
var breeze_prefetch = {"local_url":"https:\/\/sigony.com","ignore_remote_prefetch":"1","ignore_list":["wp-admin","wp-login.php"]};
/* ]]> */
</script>
<script type="text/javascript" src="https://sigony.com/wp-content/plugins/breeze/assets/js/js-front-end/breeze-prefetch-links.min.js?ver=2.2.1" id="breeze-prefetch-js"></script>

<!-- Google tag (gtag.js) snippet added by Site Kit -->

<!-- Google Analytics snippet added by Site Kit -->
<script type="text/javascript" src="https://www.googletagmanager.com/gtag/js?id=GT-TW5JDZ4P" id="google_gtagjs-js" async></script>
<script type="text/javascript" id="google_gtagjs-js-after">
/* <![CDATA[ */
window.dataLayer = window.dataLayer || [];function gtag(){dataLayer.push(arguments);}
gtag("set","linker",{"domains":["sigony.com"]});
gtag("js", new Date());
gtag("set", "developer_id.dZTNiMT", true);
gtag("config", "GT-TW5JDZ4P");
/* ]]> */
</script>

<!-- End Google tag (gtag.js) snippet added by Site Kit -->
<script></script><link rel="https://api.w.org/" href="https://sigony.com/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://sigony.com/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 6.7.1" />
<meta name="generator" content="Site Kit by Google 1.142.0" /><meta name="google-site-verification" content="1n82ZZE9X22Ji-uqyTzQjzEET0W7prZWMan2YJH8EZ8" />
<script type="text/javascript"> var root = document.getElementsByTagName( "html" )[0]; root.setAttribute( "class", "js" ); </script>
<!-- Meta Pixel Code -->
<script type='text/javascript'>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','https://connect.facebook.net/en_US/fbevents.js?v=next');
</script>
<!-- End Meta Pixel Code -->

      <script type='text/javascript'>
        var url = window.location.origin + '?ob=open-bridge';
        fbq('set', 'openbridge', '838328718266106', url);
      </script>
    <script type='text/javascript'>fbq('init', '838328718266106', {}, {
    "agent": "wordpress-6.7.1-4.0.1"
})</script><script type='text/javascript'>
    fbq('track', 'PageView', []);
  </script>
<!-- Meta Pixel Code -->
<noscript>
<img height="1" width="1" style="display:none" alt="fbpx"
src="https://www.facebook.com/tr?id=838328718266106&ev=PageView&noscript=1" />
</noscript>
<!-- End Meta Pixel Code -->
<meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>

<!-- Google Tag Manager snippet added by Site Kit -->
<script type="text/javascript">
/* <![CDATA[ */

			( function( w, d, s, l, i ) {
				w[l] = w[l] || [];
				w[l].push( {'gtm.start': new Date().getTime(), event: 'gtm.js'} );
				var f = d.getElementsByTagName( s )[0],
					j = d.createElement( s ), dl = l != 'dataLayer' ? '&l=' + l : '';
				j.async = true;
				j.src = 'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
				f.parentNode.insertBefore( j, f );
			} )( window, document, 'script', 'dataLayer', 'GTM-58MZ2528' );
			
/* ]]> */
</script>

<!-- End Google Tag Manager snippet added by Site Kit -->
<link rel="icon" href="https://sigony.com/wp-content/uploads/2024/01/cropped-SIGO_NY_favicon_01-1-32x32.png" sizes="32x32" />
<link rel="icon" href="https://sigony.com/wp-content/uploads/2024/01/cropped-SIGO_NY_favicon_01-1-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://sigony.com/wp-content/uploads/2024/01/cropped-SIGO_NY_favicon_01-1-180x180.png" />
<meta name="msapplication-TileImage" content="https://sigony.com/wp-content/uploads/2024/01/cropped-SIGO_NY_favicon_01-1-270x270.png" />
<noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript></head><body class="error404 material wpb-js-composer js-comp-ver-7.8.1 vc_responsive" data-footer-reveal="false" data-footer-reveal-shadow="none" data-header-format="centered-menu" data-body-border="off" data-boxed-style="" data-header-breakpoint="1000" data-dropdown-style="minimal" data-cae="easeOutCubic" data-cad="1300" data-megamenu-width="contained" data-aie="none" data-ls="fancybox" data-apte="standard" data-hhun="0" data-fancy-form-rcs="default" data-form-style="default" data-form-submit="regular" data-is="minimal" data-button-style="rounded" data-user-account-button="false" data-flex-cols="true" data-col-gap="default" data-header-inherit-rc="false" data-header-search="false" data-animated-anchors="true" data-ajax-transitions="false" data-full-width-header="true" data-slide-out-widget-area="true" data-slide-out-widget-area-style="fullscreen-alt" data-user-set-ocm="off" data-loading-animation="none" data-bg-header="false" data-responsive="1" data-ext-responsive="true" data-ext-padding="20" data-header-resize="0" data-header-color="custom" data-cart="false" data-remove-m-parallax="" data-remove-m-video-bgs="" data-m-animate="1" data-force-header-trans-color="light" data-smooth-scrolling="0" data-permanent-transparent="false" >
	
	<script type="text/javascript">
	 (function(window, document) {

		 if(navigator.userAgent.match(/(Android|iPod|iPhone|iPad|BlackBerry|IEMobile|Opera Mini)/)) {
			 document.body.className += " using-mobile-browser mobile ";
		 }
		 if(navigator.userAgent.match(/Mac/) && navigator.maxTouchPoints && navigator.maxTouchPoints > 2) {
			document.body.className += " using-ios-device ";
		}

		 if( !("ontouchstart" in window) ) {

			 var body = document.querySelector("body");
			 var winW = window.innerWidth;
			 var bodyW = body.clientWidth;

			 if (winW > bodyW + 4) {
				 body.setAttribute("style", "--scroll-bar-w: " + (winW - bodyW - 4) + "px");
			 } else {
				 body.setAttribute("style", "--scroll-bar-w: 0px");
			 }
		 }

	 })(window, document);
   </script>		<!-- Google Tag Manager (noscript) snippet added by Site Kit -->
		<noscript>
			<iframe src="https://www.googletagmanager.com/ns.html?id=GTM-58MZ2528" height="0" width="0" style="display:none;visibility:hidden"></iframe>
		</noscript>
		<!-- End Google Tag Manager (noscript) snippet added by Site Kit -->
		<a href="#ajax-content-wrap" class="nectar-skip-to-content">Skip to main content</a><div class="ocm-effect-wrap"><div class="ocm-effect-wrap-inner">	
	<div id="header-space"  data-header-mobile-fixed='1'></div> 
	
		<div id="header-outer" data-has-menu="true" data-has-buttons="no" data-header-button_style="hover_scale" data-using-pr-menu="true" data-mobile-fixed="1" data-ptnm="false" data-lhe="text_reveal" data-user-set-bg="#000000" data-format="centered-menu" data-permanent-transparent="false" data-megamenu-rt="0" data-remove-fixed="0" data-header-resize="0" data-cart="false" data-transparency-option="" data-box-shadow="large" data-shrink-num="10" data-using-secondary="0" data-using-logo="1" data-logo-height="30" data-m-logo-height="32" data-padding="40" data-full-width="true" data-condense="false" >
		
<div id="search-outer" class="nectar">
	<div id="search">
		<div class="container">
			 <div id="search-box">
				 <div class="inner-wrap">
					 <div class="col span_12">
						  <form role="search" action="https://sigony.com/" method="GET">
														 <input type="text" name="s" id="s" value="" aria-label="Search" placeholder="Type what you&#039;re looking for" />
							 
						<span>Hit enter to search or ESC to close</span>
						<input type="hidden" name="post_type" value="post">						</form>
					</div><!--/span_12-->
				</div><!--/inner-wrap-->
			 </div><!--/search-box-->
			 <div id="close"><a href="#"><span class="screen-reader-text">Close Search</span>
				<span class="close-wrap"> <span class="close-line close-line1"></span> <span class="close-line close-line2"></span> </span>				 </a></div>
		 </div><!--/container-->
	</div><!--/search-->
</div><!--/search-outer-->

<header id="top">
	<div class="container">
		<div class="row">
			<div class="col span_3">
								<a id="logo" href="https://sigony.com" data-supplied-ml-starting-dark="true" data-supplied-ml-starting="true" data-supplied-ml="false" >
					<img class="stnd skip-lazy default-logo" width="175" height="60" alt="SIGO NY" src="https://sigony.com/wp-content/uploads/2023/08/sigony_logo_black.png" srcset="https://sigony.com/wp-content/uploads/2023/08/sigony_logo_black.png 1x, https://sigony.com/wp-content/uploads/2023/08/sigony_logo_black@2x.png 2x" /><img class="starting-logo mobile-only-logo skip-lazy" width="400" height="137"  alt="SIGO NY" src="https://sigony.com/wp-content/uploads/2023/08/sigo_ny_logo_white@2x.png" /><img class="starting-logo dark-version mobile-only-logo skip-lazy" width="350" height="120" alt="SIGO NY" src="https://sigony.com/wp-content/uploads/2023/08/sigony_logo_black@2x.png" /><img class="starting-logo skip-lazy default-logo" width="200" height="69" alt="SIGO NY" src="https://sigony.com/wp-content/uploads/2023/08/sigo_ny_logo_white.png" srcset="https://sigony.com/wp-content/uploads/2023/08/sigo_ny_logo_white.png 1x, https://sigony.com/wp-content/uploads/2023/08/sigo_ny_logo_white@2x.png 2x" /><img class="starting-logo dark-version skip-lazy default-logo" width="175" height="60" alt="SIGO NY" src="https://sigony.com/wp-content/uploads/2023/08/sigony_logo_black.png" srcset="https://sigony.com/wp-content/uploads/2023/08/sigony_logo_black.png 1x, https://sigony.com/wp-content/uploads/2023/08/sigony_logo_black@2x.png 2x" />				</a>
							</div><!--/span_3-->

			<div class="col span_9 col_last">
									<div class="nectar-mobile-only mobile-header"><div class="inner"><ul id="menu-portfolio-layered-cta" class="sf-menu"><li id="menu-item-27088" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-btn-style-button-border-white-animated_extra-color-gradient menu-item-27088"><a href="https://sigony.com/contact"><span class="menu-title-text">Let&#8217;s Talk</span></a></li>
</ul></div></div>
													<div class="slide-out-widget-area-toggle mobile-icon fullscreen-alt" data-custom-color="true" data-icon-animation="simple-transform">
						<div> <a href="#slide-out-widget-area" role="button" aria-label="Navigation Menu" aria-expanded="false" class="closed">
							<span class="screen-reader-text">Menu</span><span aria-hidden="true"> <i class="lines-button x2" data-variant="even_lines"> <i class="lines"></i> </i> </span>						</a></div>
					</div>
				
									<nav aria-label="Main Menu">
													<ul class="sf-menu">
								<li id="menu-item-27860" class="menu-item menu-item-type-post_type menu-item-object-page nectar-regular-menu-item menu-item-27860"><a href="https://sigony.com/about-behind-strategic-branding/"><span class="menu-title-text"><span class="nectar-text-reveal-button"><span class="nectar-text-reveal-button__text" data-text="About">About</span></span></span></a></li>
<li id="menu-item-27779" class="menu-item menu-item-type-post_type menu-item-object-page nectar-regular-menu-item menu-item-27779"><a href="https://sigony.com/work-brand-identity-projects/"><span class="menu-title-text"><span class="nectar-text-reveal-button"><span class="nectar-text-reveal-button__text" data-text="Work">Work</span></span></span></a></li>
<li id="menu-item-27103" class="menu-item menu-item-type-post_type menu-item-object-page nectar-regular-menu-item menu-item-27103"><a href="https://sigony.com/service-branding-and-design/"><span class="menu-title-text"><span class="nectar-text-reveal-button"><span class="nectar-text-reveal-button__text" data-text="Services">Services</span></span></span></a></li>
<li id="menu-item-28220" class="menu-item menu-item-type-post_type menu-item-object-page nectar-regular-menu-item menu-item-28220"><a href="https://sigony.com/nova-news-branding-tactics-articles/"><span class="menu-title-text"><span class="nectar-text-reveal-button"><span class="nectar-text-reveal-button__text" data-text="News">News</span></span></span></a></li>
							</ul>
													<ul class="buttons sf-menu" data-user-set-ocm="off">

								<li class="menu-item menu-item-type-custom menu-item-object-custom nectar-regular-menu-item menu-item-btn-style-button-border-white-animated_extra-color-gradient menu-item-hover-text-reveal menu-item-27088"><a href="https://sigony.com/contact"><span class="menu-title-text"><span class="nectar-text-reveal-button"><span class="nectar-text-reveal-button__text" data-text="Let&#039;s Talk">Let&#8217;s Talk</span></span></span></a></li>

							</ul>
						
					</nav>

					<div class="logo-spacing" data-using-image="true"><img class="hidden-logo" alt="SIGO NY" width="175" height="60" src="https://sigony.com/wp-content/uploads/2023/08/sigony_logo_black.png" /></div>
				</div><!--/span_9-->

				
			</div><!--/row-->
					</div><!--/container-->
	</header>		
	</div>
		<div id="ajax-content-wrap">

<div class="container-wrap">
	
		
	<div class="container main-content">
		
		<div class="row">
			
			<div class="col span_12">
				
													<div id="error-404" 
										>
						<h1>404</h1>
						<h2>Page Not Found</h2>
						
													<a class="nectar-button large regular-button accent-color has-icon" data-color-override="false" data-hover-color-override="false" href="https://sigony.com"><span>Back Home </span><i class="icon-button-arrow"></i></a>
												</div>
								
			</div><!--/span_12-->
			
		</div><!--/row-->
		
	</div><!--/container-->
	</div><!--/container-wrap-->
<style>.wpb_row[data-using-ctc="true"] h1,
        .wpb_row[data-using-ctc="true"] h2,
        .wpb_row[data-using-ctc="true"] h3,
        .wpb_row[data-using-ctc="true"] h4,
        .wpb_row[data-using-ctc="true"] h5,
        .wpb_row[data-using-ctc="true"] h6{
          color:inherit
        }
        body .container-wrap .wpb_row[data-column-margin="none"]:not(.full-width-section):not(.full-width-content),
        html body .wpb_row[data-column-margin="none"]:not(.full-width-section):not(.full-width-content) {
          margin-bottom: 0;
        }
        
        body .container-wrap .vc_row-fluid[data-column-margin="none"] > .span_12,
        html body .vc_row-fluid[data-column-margin="none"] > .span_12,
        body .container-wrap .vc_row-fluid[data-column-margin="none"] .full-page-inner > .container > .span_12,
        body .container-wrap .vc_row-fluid[data-column-margin="none"] .full-page-inner > .span_12 {
          margin-left: 0;
          margin-right: 0;
        }
        
        body .container-wrap .vc_row-fluid[data-column-margin="none"] .wpb_column:not(.child_column),
        body .container-wrap .inner_row[data-column-margin="none"] .child_column,
        html body .vc_row-fluid[data-column-margin="none"] .wpb_column:not(.child_column),
        html body .inner_row[data-column-margin="none"] .child_column {
          padding-left: 0;
          padding-right: 0;
        }#ajax-content-wrap .vc_row.left_padding_40px .row_col_wrap_12,
            .nectar-global-section .vc_row.left_padding_40px .row_col_wrap_12 {
            padding-left: 40px;
          } #ajax-content-wrap .vc_row.right_padding_40px .row_col_wrap_12,
            .nectar-global-section .vc_row.right_padding_40px .row_col_wrap_12 {
            padding-right: 40px;
          } 
          body .container-wrap .wpb_row[data-column-margin="10px"]:not(.full-width-section):not(.full-width-content) {
            margin-bottom: 10px;
          }
        body .container-wrap .vc_row-fluid[data-column-margin="10px"] > .span_12,
        html body .vc_row-fluid[data-column-margin="10px"] > .span_12,
        body .container-wrap .vc_row-fluid[data-column-margin="10px"] .full-page-inner > .container > .span_12,
        body .container-wrap .vc_row-fluid[data-column-margin="10px"] .full-page-inner > .span_12 {
          margin-left: -5px;
          margin-right: -5px;
        }

        body .container-wrap .vc_row-fluid[data-column-margin="10px"] .wpb_column:not(.child_column),
        body .container-wrap .inner_row[data-column-margin="10px"] .child_column,
        html body .vc_row-fluid[data-column-margin="10px"] .wpb_column:not(.child_column),
        html body .inner_row[data-column-margin="10px"] .child_column {
          padding-left: 5px;
          padding-right: 5px;
        }
        .container-wrap .vc_row-fluid[data-column-margin="10px"].full-width-content > .span_12,
        html body .vc_row-fluid[data-column-margin="10px"].full-width-content > .span_12,
        .container-wrap .vc_row-fluid[data-column-margin="10px"].full-width-content .full-page-inner > .span_12 {
          margin-left: 0;
          margin-right: 0;
          padding-left: 5px;
          padding-right: 5px;
        }
        .single-portfolio #full_width_portfolio .vc_row-fluid[data-column-margin="10px"].full-width-content > .span_12 {
          padding-right: 5px;
        }
        
        @media only screen and (max-width: 999px) and (min-width: 691px) {
          .vc_row-fluid[data-column-margin="10px"] > .span_12 > .one-fourths:not([class*="vc_col-xs-"]),
          .vc_row-fluid .vc_row-fluid.inner_row[data-column-margin="10px"] > .span_12 > .one-fourths:not([class*="vc_col-xs-"]) {
            margin-bottom: 10px;
          }
        }

        @media only screen and (max-width: 999px) {
          .vc_row-fluid[data-column-margin="10px"] .wpb_column:not([class*="vc_col-xs-"]):not(.child_column):not(:last-child),
          .inner_row[data-column-margin="10px"] .child_column:not([class*="vc_col-xs-"]):not(:last-child) {
            margin-bottom: 10px;
          }
        }@media only screen , print {.wpb_column.top_padding_desktop_30px > .vc_column-inner {
              padding-top: 30px;
            }.wpb_column.right_padding_desktop_30px > .vc_column-inner {
              padding-right: 30px;
            }.wpb_column.bottom_padding_desktop_30px > .vc_column-inner {
              padding-bottom: 30px;
            }.wpb_column.left_padding_desktop_30px > .vc_column-inner {
              padding-left: 30px;
            }}@media only screen , print {.wpb_column.top_padding_desktop_30px > .n-sticky > .vc_column-inner {
              padding-top: 30px;
            }.wpb_column.right_padding_desktop_30px > .n-sticky > .vc_column-inner {
              padding-right: 30px;
            }.wpb_column.bottom_padding_desktop_30px > .n-sticky > .vc_column-inner {
              padding-bottom: 30px;
            }.wpb_column.left_padding_desktop_30px > .n-sticky > .vc_column-inner {
              padding-left: 30px;
            }}.wpb_column.el_spacing_20px > .vc_column-inner > .wpb_wrapper > div:not(:last-child),
         .wpb_column.el_spacing_20px > .n-sticky > .vc_column-inner > .wpb_wrapper > div:not(:last-child) {
          margin-bottom: 20px;
        }.wpb_column.tl_br_25px > .vc_column-inner > div[class*="-wrap"],
          .wpb_column.tl_br_25px > .vc_column-inner {
            border-top-left-radius: 25px;
            overflow: hidden;
          }.wpb_column.tr_br_25px > .vc_column-inner > div[class*="-wrap"],
          .wpb_column.tr_br_25px > .vc_column-inner  {
            border-top-right-radius: 25px;
            overflow: hidden;
          }.wpb_column.bl_br_25px > .vc_column-inner > div[class*="-wrap"],
          .wpb_column.bl_br_25px > .vc_column-inner  {
            border-bottom-left-radius: 25px;
            overflow: hidden;
          }.wpb_column.br_br_25px > .vc_column-inner > div[class*="-wrap"],
          .wpb_column.br_br_25px > .vc_column-inner  {
            border-bottom-right-radius: 25px;
            overflow: hidden;
          }.wpb_column.el_spacing_0px > .vc_column-inner > .wpb_wrapper > div:not(:last-child),
         .wpb_column.el_spacing_0px > .n-sticky > .vc_column-inner > .wpb_wrapper > div:not(:last-child) {
          margin-bottom: 0px;
        }.wpb_column.child_column.el_spacing_10px > .vc_column-inner > .wpb_wrapper > div:not(:last-child),
         .wpb_column.child_column.el_spacing_10px > .n-sticky > .vc_column-inner > .wpb_wrapper > div:not(:last-child) {
          margin-bottom: 10px;
        }@media only screen , print { 
            .wpb_column.force-desktop-text-align-left,
            .wpb_column.force-desktop-text-align-left .col {
              text-align: left!important;
            }
          
            .wpb_column.force-desktop-text-align-right,
            .wpb_column.force-desktop-text-align-right .col {
              text-align: right!important;
            }
          
            .wpb_column.force-desktop-text-align-center,
            .wpb_column.force-desktop-text-align-center .col,
            .wpb_column.force-desktop-text-align-center .vc_custom_heading,
            .wpb_column.force-desktop-text-align-center .nectar-cta {
              text-align: center!important;
            }
          
            .wpb_column.force-desktop-text-align-center .img-with-aniamtion-wrap img {
              display: inline-block;
            }
          }@media only screen and (min-width: 1000px) {
            .column_element_direction_desktop_horizontal > .vc_column-inner > .wpb_wrapper {
              display: flex; 
              align-items: center;
            }
            #ajax-content-wrap .column_element_direction_desktop_horizontal > .vc_column-inner > .wpb_wrapper > * {
              margin-bottom: 0;
            }
          }
          .column_element_direction_desktop_horizontal.force-desktop-text-align-right > .vc_column-inner > .wpb_wrapper {
            justify-content: flex-end;
          }
          .column_element_direction_desktop_horizontal.force-desktop-text-align-center > .vc_column-inner > .wpb_wrapper {
            justify-content: center;
          }

          @media only screen and (max-width: 999px) {
            .column_element_direction_desktop_horizontal.force-tablet-text-align-right > .vc_column-inner > .wpb_wrapper {
              justify-content: flex-end;
            }
            .column_element_direction_desktop_horizontal.force-tablet-text-align-center > .vc_column-inner > .wpb_wrapper {
              justify-content: center;
            }
          }

          @media only screen and (max-width: 690px) {
            .column_element_direction_desktop_horizontal.force-phone-text-align-right > .vc_column-inner > .wpb_wrapper {
              justify-content: flex-end;
            }
            .column_element_direction_desktop_horizontal.force-phone-text-align-center > .vc_column-inner > .wpb_wrapper {
              justify-content: center;
            }
          }
          @media only screen and (min-width: 1000px) {
            .column_element_direction_desktop_horizontal.el_spacing_10px > .vc_column-inner > .wpb_wrapper{
              gap: 10px;
            }
          }@media only screen and (min-width: 691px) and (max-width: 999px) {
            .column_element_direction_tablet_horizontal > .vc_column-inner > .wpb_wrapper {
              display: flex; 
              align-items: center;
            }
            #ajax-content-wrap .column_element_direction_tablet_horizontal > .vc_column-inner > .wpb_wrapper > * {
              margin-bottom: 0;
            }
          }@media only screen and (min-width: 691px) and (max-width: 999px) {
            .column_element_direction_desktop_horizontal.el_spacing_10px > .vc_column-inner > .wpb_wrapper{
              gap: 10px;
            }
          }
      .nectar_icon_wrap i {
        vertical-align: middle;
        top: 0;
      }
      .nectar_icon_wrap i[class*="nectar-brands"] {
        display: inline-block;
      }
      .wpb_wrapper > .nectar_icon_wrap  {
        margin-bottom: 0;
      }
      .nectar_icon_wrap i {
        transition: color .25s ease;
      }
      .nectar_icon_wrap path {
        transition: fill .25s ease;
      }
            .nectar-pulsate i {
              display: block;
              border-radius: 200px;
              background-color: currentColor;
              position: relative;
            }
            .nectar-pulsate i:after {
                display: block;
                position: absolute;
                top: 50%;
                left: 50%;
                content: "";
                width: 100%;
                height: 100%;
                margin: -50% auto auto -50%;
                -webkit-transform-origin: 50% 50%;
                transform-origin: 50% 50%;
                border-radius: 50%;
                background-color: currentColor;
                opacity: 1;
                z-index: 11;
                pointer-events: none;
                animation: nectar_pulsate 2s cubic-bezier(.2,1,.2,1) infinite;
            }

            @keyframes nectar_pulsate { 
                0% {
                    opacity: 0.6;
                    transform: scale(1);
                }
                100% {
                    opacity: 0;
                    transform: scale(3);
                }
            }
          .nectar_icon_wrap[data-style*="default"][data-color*="extra-color-gradient"] .nectar_icon i {
            border-radius: 0!important;
            text-align: center;
          }
          .nectar_icon_wrap[data-style*="default"][data-color*="extra-color-gradient"] .nectar_icon i:before {
            vertical-align: top;
          }
          .nectar_icon_wrap[data-style*="default"][data-color*="extra-color-gradient"] .nectar_icon i[class*="fa-"],
          .nectar_icon_wrap[data-style*="default"][data-color*="extra-color-gradient"] .nectar_icon i[class^="icon-"] {
            vertical-align: baseline;
          }
        .nectar_icon_wrap[data-style="default"] .icon_color_custom_c51fe2 i {
                color: #c51fe2!important;
              }.nectar_icon_wrap[data-style="default"] .icon_color_custom_c51fe2 .im-icon-wrap path {
                fill: #c51fe2;
              }.nectar_icon_wrap:not([data-style="soft-bg"]):not([data-style="shadow-bg"]) .nectar_icon.icon_color_custom_c51fe2 .svg-icon-holder[data-color] svg path {
              stroke: #c51fe2!important;
            }
        .nectar-split-heading .heading-line{
          display:block;
          overflow:hidden;
          position:relative
        }
        .nectar-split-heading .heading-line >div{
          display:block;
          transform:translateY(200%);
          -webkit-transform:translateY(200%)
        }
        
        .nectar-split-heading h1{
          margin-bottom:0
        }.nectar-split-heading[data-has-fit-text="true"]:not(.fitty-fit) {
              opacity: 0!important;
            }.nectar-split-heading[data-has-fit-text="true"] {
            white-space: nowrap;
            display: inline-block;
          }
          .nectar-split-heading[data-has-fit-text="true"] * {
            font-size: inherit;
          }
          .nectar-split-heading[data-has-fit-text="true"][data-text-effect] * {
            line-height: 1; 
          }.centered-text .nectar-split-heading[data-animation-type="line-reveal-by-space"] h1,
          .centered-text .nectar-split-heading[data-animation-type="line-reveal-by-space"] h2,
          .centered-text .nectar-split-heading[data-animation-type="line-reveal-by-space"] h3,
          .centered-text .nectar-split-heading[data-animation-type="line-reveal-by-space"] h4 {
            margin: 0 auto;
          }
          .nectar-split-heading[data-animation-type="line-reveal-by-space"]:not(.markup-generated) {
            opacity: 0;
          }
          .nectar-split-heading[data-animation-type="line-reveal-by-space"]:not(.markup-generated).animated-in {
              opacity: 1;
          }
          @media only screen and (max-width: 999px) {
            .nectar-split-heading[data-m-rm-animation="true"] {
              opacity: 1!important;
            }
          }
          
          .nectar-split-heading[data-animation-type="line-reveal-by-space"] > * > span  {
            position: relative;
            display: inline-block;
            overflow: hidden;
          }
          
          .nectar-split-heading[data-animation-type="line-reveal-by-space"] span {
             vertical-align: bottom;
          }
          
          .nectar-split-heading[data-animation-type="line-reveal-by-space"] span {
            line-height: 1.2;
          }

          @media only screen and (min-width: 1000px) {
            .nectar-split-heading[data-animation-type="line-reveal-by-space"]:not(.markup-generated) > * {
              line-height: 1.2;
            }
          }
          @media only screen and (max-width: 999px) {
            .nectar-split-heading[data-animation-type="line-reveal-by-space"]:not([data-m-rm-animation="true"]):not(.markup-generated) > * {
              line-height: 1.2;
            }
          }

          .nectar-split-heading[data-animation-type="line-reveal-by-space"][data-stagger="true"]:not([data-text-effect*="letter-reveal"]) span .inner {
            transition: transform 1.2s cubic-bezier(0.25, 1, 0.5, 1), opacity 1.2s cubic-bezier(0.25, 1, 0.5, 1);
          }
          .nectar-split-heading[data-animation-type="line-reveal-by-space"] span .inner {
            position: relative;
            display: inline-block;
            -webkit-transform: translateY(1.3em);
            transform: translateY(1.3em);
          }
          .nectar-split-heading[data-animation-type="line-reveal-by-space"] span .inner.animated {
            -webkit-transform: none;
            transform: none;
            opacity: 1;
          }
            .nectar-split-heading[data-animation-type="line-reveal-by-space"][data-text-effect="letter-reveal-bottom"] > * > span {
              padding: 0 0.05em;
              margin: 0 -0.05em;
            }.nectar-split-heading[data-animation-type="line-reveal-by-space"][data-align="left"] {
            display: flex;
            justify-content: flex-start;
          }
          .nectar-split-heading[data-animation-type="line-reveal-by-space"][data-align="center"] {
            display: flex;
            justify-content: center;
          }
          .nectar-split-heading[data-animation-type="line-reveal-by-space"][data-align="right"] {
            display: flex;
            justify-content: flex-end;
          }
          @media only screen and (max-width: 999px) {
            .nectar-split-heading[data-animation-type="line-reveal-by-space"][data-m-align="left"] {
              display: flex;
              justify-content: flex-start;
            }
            .nectar-split-heading[data-animation-type="line-reveal-by-space"][data-m-align="center"] {
              display: flex;
              justify-content: center;
            }
            .nectar-split-heading[data-animation-type="line-reveal-by-space"][data-m-align="right"] {
              display: flex;
              justify-content: flex-end;
            }
          }@media only screen , print {
          body #ajax-content-wrap .font_size_desktop_7vw.font_size_max_130px.nectar-cta,
          body .font_size_desktop_7vw.font_size_max_130px.nectar-cta {
            font-size: min(130px,7vw);
          }
        }@media only screen , print {
          body #ajax-content-wrap .font_size_desktop_7vw.font_size_max_130px.nectar-cta,
          body .font_size_desktop_7vw.font_size_max_130px.nectar-cta,
          body #header-outer .font_size_desktop_7vw.font_size_max_130px.nectar-cta {
            font-size: min(130px,7vw);
          }
        }@media only screen and (max-width: 690px) {
          html body #ajax-content-wrap .font_size_phone_10vw.font_size_max_130px.nectar-cta,
          html body .font_size_phone_10vw.font_size_max_130px.nectar-cta {
            font-size: min(130px,10vw);
          }
        }@media only screen and (max-width: 690px) {
          html body #ajax-content-wrap .container-wrap .font_size_phone_10vw.font_size_max_130px.nectar-cta,
          html body .container-wrap .font_size_phone_10vw.font_size_max_130px.nectar-cta,
          html body #header-outer .font_size_phone_10vw.font_size_max_130px.nectar-cta {
            font-size: min(130px,10vw);
          }
        }@media only screen , print {
          body #ajax-content-wrap .font_size_desktop_7vw.font_size_max_130px.nectar-cta *,
          body .font_size_desktop_7vw.font_size_max_130px.nectar-cta * {
            font-size: min(130px,7vw);
          }
        }@media only screen , print {
          body #ajax-content-wrap .font_size_desktop_7vw.font_size_max_130px.nectar-cta *,
          body .font_size_desktop_7vw.font_size_max_130px.nectar-cta *,
          body #header-outer .font_size_desktop_7vw.font_size_max_130px.nectar-cta * {
            font-size: min(130px,7vw);
          }
        }@media only screen and (max-width: 690px) {
          html body #ajax-content-wrap .font_size_phone_10vw.font_size_max_130px.nectar-cta *,
          html body .font_size_phone_10vw.font_size_max_130px.nectar-cta * {
            font-size: min(130px,10vw);
          }
        }@media only screen and (max-width: 690px) {
          html body #ajax-content-wrap .container-wrap .font_size_phone_10vw.font_size_max_130px.nectar-cta *,
          html body .container-wrap .font_size_phone_10vw.font_size_max_130px.nectar-cta *,
          html body #header-outer .font_size_phone_10vw.font_size_max_130px.nectar-cta * {
            font-size: min(130px,10vw);
          }
        }.nectar-cta.font_size_desktop_7vw,
          .nectar-cta.font_size_desktop_7vw * {
            line-height: 1.1;
          }
      #ajax-content-wrap .nectar-responsive-text *,
       body .nectar-responsive-text * {
        margin-bottom: 0;
        color: inherit;
      }
      #ajax-content-wrap .nectar-responsive-text[class*="font_size"] *,
      body .nectar-responsive-text[class*="font_size"] * {
        font-size: inherit; 
        line-height: inherit;
      }
      .nectar-responsive-text.nectar-link-underline-effect a {
        text-decoration: none;
      }
      .nectar-responsive-text[data-inherit-heading-family] > * {
        font-family: inherit;
        font-weight: inherit;
        font-size: inherit;
        line-height: inherit;
        text-transform: inherit;
        letter-spacing: inherit;
      }
      #ajax-content-wrap .font_line_height_1px.nectar-responsive-text,
      body .font_line_height_1px.nectar-responsive-text  {
          line-height: 1;
      }@media only screen and (max-width: 999px) { .vc_row.bottom_padding_tablet_6pct {
              padding-bottom: 6%!important;
            } }@media only screen and (max-width: 999px) { #ajax-content-wrap .vc_row.right_padding_tablet_6pct .row_col_wrap_12 {
              padding-right: 6%!important;
            } }@media only screen and (max-width: 999px) {
                .nectar-cta.display_tablet_inherit {
                display: inherit;
              }
            }@media only screen and (max-width: 999px) { 
            body .wpb_column.force-tablet-text-align-left,
            body .wpb_column.force-tablet-text-align-left .col {
              text-align: left!important;
            }
          
            body .wpb_column.force-tablet-text-align-right,
            body .wpb_column.force-tablet-text-align-right .col {
              text-align: right!important;
            }
          
            body .wpb_column.force-tablet-text-align-center,
            body .wpb_column.force-tablet-text-align-center .col,
            body .wpb_column.force-tablet-text-align-center .vc_custom_heading,
            body .wpb_column.force-tablet-text-align-center .nectar-cta {
              text-align: center!important;
            }
          
            .wpb_column.force-tablet-text-align-center .img-with-aniamtion-wrap img {
              display: inline-block;
            }
          }@media only screen and (max-width: 999px) { #ajax-content-wrap .vc_row.left_padding_tablet_6pct .row_col_wrap_12 {
              padding-left: 6%!important;
            } }@media only screen and (max-width: 690px) { 
            html body .nectar-cta.font_size_phone_10vw,
            html body .nectar-cta.font_size_phone_10vw * {
              line-height: 1.1;
          }
          }@media only screen and (max-width: 690px) { .vc_row.top_padding_phone_1pct {
              padding-top: 1%!important;
            } }@media only screen and (max-width: 690px) {
            .column_element_direction_phone_horizontal > .vc_column-inner > .wpb_wrapper {
              display: flex; 
              align-items: center;
            }
            #ajax-content-wrap .column_element_direction_phone_horizontal > .vc_column-inner > .wpb_wrapper > * {
              margin-bottom: 0;
            }
          }@media only screen and (max-width: 690px) {
              .nectar-cta.display_phone_inherit {
              display: inherit;
            }
          }@media only screen and (max-width: 690px) {
            .column_element_direction_desktop_horizontal.el_spacing_10px > .vc_column-inner > .wpb_wrapper{
              gap: 10px;
            }
          }@media only screen and (max-width: 690px) { 
            html body .wpb_column.force-phone-text-align-left,
            html body .wpb_column.force-phone-text-align-left .col {
              text-align: left!important;
            }
          
            html body .wpb_column.force-phone-text-align-right,
            html body .wpb_column.force-phone-text-align-right .col {
              text-align: right!important;
            }
          
            html body .wpb_column.force-phone-text-align-center,
            html body .wpb_column.force-phone-text-align-center .col,
            html body .wpb_column.force-phone-text-align-center .vc_custom_heading,
            html body .wpb_column.force-phone-text-align-center .nectar-cta {
              text-align: center!important;
            }
          
            .wpb_column.force-phone-text-align-center .img-with-aniamtion-wrap img {
              display: inline-block;
            }
          }</style><div class="nectar-global-section nectar_hook_global_section_footer"><div class="container normal-container row"> 
		<div id="fws_677f03c61f5ad"  data-column-margin="default" data-midnight="dark" data-top-percent="6%"  class="wpb_row vc_row-fluid vc_row full-width-section  zindex-set top_padding_phone_1pct" data-using-ctc="true" style="padding-top: calc(100vw * 0.06); padding-bottom: 0px;  z-index: 1000;color: #000000; "><div class="row-bg-wrap" data-bg-animation="none" data-bg-animation-delay="" data-bg-overlay="false"><div class="inner-wrap row-bg-layer" ><div class="row-bg viewport-desktop using-bg-color"  style="background-color: #000000; "></div></div></div><div class="row_col_wrap_12 col span_12 custom left">
	<div style="" class="vc_col-sm-12 wpb_column column_container vc_column_container col el_spacing_20px tl_br_25px tr_br_25px bl_br_25px br_br_25px left_padding_desktop_30px top_padding_desktop_30px right_padding_desktop_30px bottom_padding_desktop_30px " data-using-bg="true" data-padding-pos="all" data-has-bg-color="true" data-bg-color="#ffffff" data-bg-opacity="1" data-animation="" data-delay="0" >
		<div class="vc_column-inner" ><div class="column-bg-overlay-wrap column-bg-layer" data-bg-animation="none"><div class="column-bg-overlay" style="opacity: 1; background-color: #ffffff;"></div></div>
			<div class="wpb_wrapper">
				<div class="divider-wrap" data-alignment="default"><div style="height: 4vw;" class="divider"></div></div><div id="fws_677f03c622a4a" data-midnight="" data-column-margin="default" class="wpb_row vc_row-fluid vc_row inner_row"  style=""><div class="row-bg-wrap"> <div class="row-bg" ></div> </div><div class="row_col_wrap_12_inner col span_12  left">
	<div  class="vc_col-sm-12 wpb_column column_container vc_column_container col child_column no-extra-padding column_element_direction_desktop_horizontal force-desktop-text-align-center column_element_direction_tablet_horizontal column_element_direction_phone_horizontal el_spacing_10px inherit_tablet inherit_phone "   data-padding-pos="all" data-has-bg-color="false" data-bg-color="" data-bg-opacity="1" data-animation="" data-delay="0" >
		<div class="vc_column-inner" >
		<div class="wpb_wrapper">
			<div class="nectar_icon_wrap  nectar-pulsate" data-style="default" data-padding="0px" data-color="accent-color" style="" >
		<div class="nectar_icon icon_color_custom_c51fe2 " ><i style="font-size: 8px; line-height: 8px; height: 8px; width: 8px;" class=""></i></div>
	</div><div class="nectar-responsive-text nectar-link-underline-effect"><p>Lunch&#8217;s on Us.</p>
</div>
		</div> 
	</div>
	</div> 
</div></div><div id="fws_677f03c62312f" data-midnight="" data-column-margin="default" class="wpb_row vc_row-fluid vc_row inner_row"  style=""><div class="row-bg-wrap"> <div class="row-bg" ></div> </div><div class="row_col_wrap_12_inner col span_12  left">
	<div  class="vc_col-sm-12 wpb_column column_container vc_column_container col child_column no-extra-padding force-desktop-text-align-center inherit_tablet inherit_phone "   data-padding-pos="all" data-has-bg-color="false" data-bg-color="" data-bg-opacity="1" data-animation="" data-delay="0" >
		<div class="vc_column-inner" >
		<div class="wpb_wrapper">
			<div class="nectar-cta  alignment_tablet_default alignment_phone_default display_tablet_inherit display_phone_inherit font_size_desktop_7vw font_size_phone_10vw font_size_max_130px " data-color="default" data-using-bg="false" data-style="text-reveal" data-display="block" data-alignment="left" data-text-color="std" ><h2><span class="link_wrap" ><a  class="link_text" role="button" href="https://sigony.com/contact/"><span class="text nectar-text-reveal-button__text"data-text="Let&#039;s Talk">Let's Talk</span></a></span></h2></div>
		</div> 
	</div>
	</div> 
</div></div><div id="fws_677f03c6239cf" data-midnight="" data-column-margin="default" class="wpb_row vc_row-fluid vc_row inner_row"  style=""><div class="row-bg-wrap"> <div class="row-bg" ></div> </div><div class="row_col_wrap_12_inner col span_12  left">
	<div  class="vc_col-sm-12 wpb_column column_container vc_column_container col child_column no-extra-padding column_element_direction_desktop_horizontal force-desktop-text-align-center column_element_direction_tablet_horizontal el_spacing_10px inherit_tablet inherit_phone "   data-padding-pos="all" data-has-bg-color="false" data-bg-color="" data-bg-opacity="1" data-animation="" data-delay="0" >
		<div class="vc_column-inner" >
		<div class="wpb_wrapper">
			<div class="nectar-cta  alignment_tablet_default alignment_phone_default display_tablet_inherit display_phone_inherit " data-color="default" data-using-bg="false" data-display="block" data-style="underline" data-alignment="left" data-text-color="std" style="margin-right: 10px; margin-left: 10px;"><p> <span class="link_wrap" ><a target="_blank" class="link_text"  role="button" href="https://www.behance.net/sigony">Behance</a></span></p></div><div class="nectar-cta  alignment_tablet_default alignment_phone_default display_tablet_inherit display_phone_inherit " data-color="default" data-using-bg="false" data-display="block" data-style="underline" data-alignment="left" data-text-color="std" style="margin-right: 10px; margin-left: 10px;"><p> <span class="link_wrap" ><a target="_blank" class="link_text"  role="button" href="https://www.facebook.com/sigony.agency/">Facebook</a></span></p></div><div class="nectar-cta  alignment_tablet_default alignment_phone_default display_tablet_inherit display_phone_inherit " data-color="default" data-using-bg="false" data-display="block" data-style="underline" data-alignment="left" data-text-color="std" style="margin-right: 10px; margin-left: 10px;"><p> <span class="link_wrap" ><a target="_blank" class="link_text"  role="button" href="https://www.instagram.com/sigonewyork/">Instagram</a></span></p></div><div class="nectar-cta  alignment_tablet_default alignment_phone_default display_tablet_inherit display_phone_inherit " data-color="default" data-using-bg="false" data-display="block" data-style="underline" data-alignment="left" data-text-color="std" style="margin-right: 10px; margin-left: 10px;"><p> <span class="link_wrap" ><a target="_blank" class="link_text"  role="button" href="https://www.linkedin.com/company/sigony/">LinkedIn</a></span></p></div>
		</div> 
	</div>
	</div> 
</div></div><div class="divider-wrap" data-alignment="default"><div style="height: 3vw;" class="divider"></div></div><div id="fws_677f03c623d4d" data-midnight="" data-column-margin="10px" class="wpb_row vc_row-fluid vc_row inner_row"  style=""><div class="row-bg-wrap"> <div class="row-bg" ></div> </div><div class="row_col_wrap_12_inner col span_12  left">
	<div  class="vc_col-sm-4 wpb_column column_container vc_column_container col child_column no-extra-padding force-tablet-text-align-center force-phone-text-align-center inherit_tablet inherit_phone "   data-padding-pos="all" data-has-bg-color="false" data-bg-color="" data-bg-opacity="1" data-animation="" data-delay="0" >
		<div class="vc_column-inner" >
		<div class="wpb_wrapper">
			<div class="nectar-responsive-text font_line_height_1px nectar-link-underline-effect"><h6><span style="color: #999999"><a style="color: #999999" href="https://sigony.com/privacy-policy/">PRIVACY POLICY</a></span></h6>
</div>
		</div> 
	</div>
	</div> 

	<div  class="vc_col-sm-4 wpb_column column_container vc_column_container col child_column no-extra-padding force-desktop-text-align-center force-tablet-text-align-center force-phone-text-align-center inherit_tablet inherit_phone "   data-padding-pos="all" data-has-bg-color="false" data-bg-color="" data-bg-opacity="1" data-animation="" data-delay="0" >
		<div class="vc_column-inner" >
		<div class="wpb_wrapper">
			
		</div> 
	</div>
	</div> 

	<div  class="vc_col-sm-4 wpb_column column_container vc_column_container col child_column no-extra-padding force-desktop-text-align-right force-phone-text-align-center inherit_tablet inherit_phone "   data-padding-pos="all" data-has-bg-color="false" data-bg-color="" data-bg-opacity="1" data-animation="" data-delay="0" >
		<div class="vc_column-inner" >
		<div class="wpb_wrapper">
			<div class="nectar-responsive-text font_line_height_1px nectar-link-underline-effect"><h6><span style="color: #999999">SIGO NY™  ALL RIGHTS RESERVED</span></h6>
</div>
		</div> 
	</div>
	</div> 
</div></div>
			</div> 
		</div>
	</div> 
</div></div>
		<div id="fws_677f03c62457c"  data-column-margin="none" data-midnight="light" data-top-percent="4%"  class="wpb_row vc_row-fluid vc_row full-width-content vc_row-o-equal-height vc_row-flex vc_row-o-content-top  right_padding_40px left_padding_40px nectar-overflow-hidden bottom_padding_tablet_6pct right_padding_tablet_6pct left_padding_tablet_6pct"  style="padding-top: calc(100vw * 0.04); padding-bottom: 40px; "><div class="row-bg-wrap" data-bg-animation="none" data-bg-animation-delay="" data-bg-overlay="false"><div class="inner-wrap row-bg-layer" ><div class="row-bg viewport-desktop using-bg-color"  style="background-color: #000000; "></div></div></div><div class="row_col_wrap_12 col span_12 light left">
	<div  class="vc_col-sm-12 wpb_column column_container vc_column_container col no-extra-padding el_spacing_0px inherit_tablet inherit_phone "  data-padding-pos="all" data-has-bg-color="false" data-bg-color="" data-bg-opacity="1" data-animation="" data-delay="0" >
		<div class="vc_column-inner" >
			<div class="wpb_wrapper">
				<div id="fws_677f03c6249c3" data-midnight="" data-column-margin="default" class="wpb_row vc_row-fluid vc_row inner_row"  style=""><div class="row-bg-wrap"> <div class="row-bg" ></div> </div><div class="row_col_wrap_12_inner col span_12  left">
	<div  class="vc_col-sm-12 wpb_column column_container vc_column_container col child_column no-extra-padding inherit_tablet inherit_phone "   data-padding-pos="all" data-has-bg-color="false" data-bg-color="" data-bg-opacity="1" data-animation="" data-delay="0" >
		<div class="vc_column-inner" >
		<div class="wpb_wrapper">
			<div class="nectar-split-heading " data-align="default" data-m-align="inherit" data-text-effect="letter-reveal-bottom" data-animation-type="line-reveal-by-space" data-animation-delay="0" data-animation-offset="96%" data-m-rm-animation="" data-stagger="true" data-custom-font-size="false" data-has-fit-text="true" ><h1 >© — <span class="nectar-current-year">2025</span></h1></div>
		</div> 
	</div>
	</div> 
</div></div>
			</div> 
		</div>
	</div> 
</div></div>
 </div></div>
<div id="footer-outer" data-midnight="light" data-cols="4" data-custom-color="false" data-disable-copyright="true" data-matching-section-color="true" data-copyright-line="false" data-using-bg-img="false" data-bg-img-overlay="0.8" data-full-width="false" data-using-widget-area="false" data-link-hover="default">
	
		
</div><!--/footer-outer-->


	<div id="slide-out-widget-area-bg" class="fullscreen-alt solid">
		<div class="bg-inner"></div>		</div>

		<div id="slide-out-widget-area" class="fullscreen-alt" data-dropdown-func="default" data-back-txt="Back">

			<div class="inner-wrap">
			<div class="inner" data-prepend-menu-mobile="false">

				<a class="slide_out_area_close" href="#"><span class="screen-reader-text">Close Menu</span>
					<span class="close-wrap"> <span class="close-line close-line1"></span> <span class="close-line close-line2"></span> </span>				</a>


									<div class="off-canvas-menu-container mobile-only" role="navigation">

						
						<ul class="menu">
							<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-27860"><a href="https://sigony.com/about-behind-strategic-branding/">About</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-27779"><a href="https://sigony.com/work-brand-identity-projects/">Work</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-27103"><a href="https://sigony.com/service-branding-and-design/">Services</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-28220"><a href="https://sigony.com/nova-news-branding-tactics-articles/">News</a></li>

						</ul>

						<ul class="menu secondary-header-items">
													</ul>
					</div>
					
				</div>

				<div class="bottom-meta-wrap"></div><!--/bottom-meta-wrap--></div> <!--/inner-wrap-->
				</div>
		
</div> <!--/ajax-content-wrap-->

</div></div><!--/ocm-effect-wrap-->    <!-- Meta Pixel Event Code -->
    <script type='text/javascript'>
        document.addEventListener( 'wpcf7mailsent', function( event ) {
        if( "fb_pxl_code" in event.detail.apiResponse){
          eval(event.detail.apiResponse.fb_pxl_code);
        }
      }, false );
    </script>
    <!-- End Meta Pixel Event Code -->
    <div id='fb-pxl-ajax-code'></div><script type="text/html" id="wpb-modifications"> window.wpbCustomElement = 1; </script><link data-pagespeed-no-defer data-nowprocket data-wpacu-skip data-no-optimize data-noptimize rel='stylesheet' id='main-styles-non-critical-css' href='https://sigony.com/wp-content/themes/salient/css/build/style-non-critical.css?ver=17.0.2' type='text/css' media='all' />
<link data-pagespeed-no-defer data-nowprocket data-wpacu-skip data-no-optimize data-noptimize rel='stylesheet' id='fancyBox-css' href='https://sigony.com/wp-content/themes/salient/css/build/plugins/jquery.fancybox.css?ver=3.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='nectar-smooth-scroll-css' href='https://sigony.com/wp-content/themes/salient/css/build/plugins/lenis.css?ver=17.0.2' type='text/css' media='all' />
<link data-pagespeed-no-defer data-nowprocket data-wpacu-skip data-no-optimize data-noptimize rel='stylesheet' id='nectar-ocm-core-css' href='https://sigony.com/wp-content/themes/salient/css/build/off-canvas/core.css?ver=17.0.2' type='text/css' media='all' />
<link data-pagespeed-no-defer data-nowprocket data-wpacu-skip data-no-optimize data-noptimize rel='stylesheet' id='nectar-ocm-fullscreen-legacy-css' href='https://sigony.com/wp-content/themes/salient/css/build/off-canvas/fullscreen-legacy.css?ver=17.0.2' type='text/css' media='all' />
<script type="text/javascript" src="https://sigony.com/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script type="text/javascript" src="https://sigony.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<script data-pagespeed-no-defer data-nowprocket data-wpacu-skip data-no-optimize type="text/javascript" src="https://sigony.com/wp-content/themes/salient/js/build/third-party/jquery.easing.min.js?ver=1.3" id="jquery-easing-js"></script>
<script data-pagespeed-no-defer data-nowprocket data-wpacu-skip data-no-optimize type="text/javascript" src="https://sigony.com/wp-content/themes/salient/js/build/third-party/jquery.mousewheel.min.js?ver=3.1.13" id="jquery-mousewheel-js"></script>
<script type="text/javascript" src="https://sigony.com/wp-content/themes/salient/js/build/priority.js?ver=17.0.2" id="nectar_priority-js"></script>
<script type="text/javascript" src="https://sigony.com/wp-content/themes/salient/js/build/third-party/transit.min.js?ver=0.9.9" id="nectar-transit-js"></script>
<script data-pagespeed-no-defer data-nowprocket data-wpacu-skip data-no-optimize type="text/javascript" src="https://sigony.com/wp-content/themes/salient/js/build/third-party/waypoints.js?ver=4.0.2" id="nectar-waypoints-js"></script>
<script type="text/javascript" src="https://sigony.com/wp-content/plugins/salient-portfolio/js/third-party/imagesLoaded.min.js?ver=4.1.4" id="imagesLoaded-js"></script>
<script data-pagespeed-no-defer data-nowprocket data-wpacu-skip data-no-optimize type="text/javascript" src="https://sigony.com/wp-content/themes/salient/js/build/third-party/hoverintent.min.js?ver=1.9" id="hoverintent-js"></script>
<script type="text/javascript" src="https://sigony.com/wp-content/themes/salient/js/build/third-party/jquery.fancybox.js?ver=3.3.9" id="fancyBox-js"></script>
<script type="text/javascript" src="https://sigony.com/wp-content/themes/salient/js/build/third-party/anime.min.js?ver=4.5.1" id="anime-js"></script>
<script data-pagespeed-no-defer data-nowprocket data-wpacu-skip data-no-optimize type="text/javascript" src="https://sigony.com/wp-content/themes/salient/js/build/third-party/superfish.js?ver=1.5.8" id="superfish-js"></script>
<script type="text/javascript" id="nectar-frontend-js-extra">
/* <![CDATA[ */
var nectarLove = {"ajaxurl":"https:\/\/sigony.com\/wp-admin\/admin-ajax.php","postID":"141","rooturl":"https:\/\/sigony.com","disqusComments":"false","loveNonce":"0d18e966b1","mapApiKey":""};
var nectarOptions = {"delay_js":"false","smooth_scroll":"true","smooth_scroll_strength":"50","quick_search":"false","react_compat":"disabled","header_entrance":"false","body_border_func":"default","body_border_mobile":"0","dropdown_hover_intent":"default","simplify_ocm_mobile":"0","mobile_header_format":"default","ocm_btn_position":"default","left_header_dropdown_func":"default","ajax_add_to_cart":"0","ocm_remove_ext_menu_items":"remove_images","woo_product_filter_toggle":"0","woo_sidebar_toggles":"true","woo_sticky_sidebar":"0","woo_minimal_product_hover":"default","woo_minimal_product_effect":"default","woo_related_upsell_carousel":"false","woo_product_variable_select":"default","woo_using_cart_addons":"false","view_transitions_effect":"reveal-from-bottom"};
var nectar_front_i18n = {"menu":"Menu","next":"Next","previous":"Previous","close":"Close"};
/* ]]> */
</script>
<script data-pagespeed-no-defer data-nowprocket data-wpacu-skip data-no-optimize type="text/javascript" src="https://sigony.com/wp-content/themes/salient/js/build/init.js?ver=17.0.2" id="nectar-frontend-js"></script>
<script type="text/javascript" src="https://sigony.com/wp-content/themes/salient/js/build/nectar-smooth-scroll.js?ver=17.0.2" id="nectar-smooth-scroll-js"></script>
<script data-pagespeed-no-defer data-nowprocket data-wpacu-skip data-no-optimize type="text/javascript" src="https://sigony.com/wp-content/plugins/salient-core/js/third-party/touchswipe.min.js?ver=1.0" id="touchswipe-js"></script>
<script type="text/javascript" src="https://sigony.com/wp-content/plugins/breeze/assets/js/js-front-end/breeze-lazy-load.min.js?ver=2.2.1" id="breeze-lazy-js"></script>
<script type="text/javascript" id="breeze-lazy-js-after">
/* <![CDATA[ */
document.querySelectorAll('img[data-breeze]').forEach(img=>{if(img.getBoundingClientRect().top<=window.innerHeight){img.src=img.getAttribute('data-breeze');img.removeAttribute('data-breeze')}});
/* ]]> */
</script>
<script data-pagespeed-no-defer data-nowprocket data-wpacu-skip data-no-optimize type="text/javascript" src="https://sigony.com/wp-content/plugins/js_composer_salient/assets/js/dist/js_composer_front.min.js?ver=7.8.1" id="wpb_composer_front_js-js"></script>
<script type="text/javascript" src="https://sigony.com/wp-content/themes/salient/js/build/elements/nectar-fit-text.js?ver=17.0.2" id="nectar-fit-text-js"></script>
<script></script></body>
</html>